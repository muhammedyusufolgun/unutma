# Unutma — Zamanlı Sesli Mesaj

Android Studio ile açılabilen Kotlin tabanlı uygulama kaynak kodudur.

## Derleme
Android Studio'da projeyi açın, Gradle senkronizasyonunu tamamlayın, **Build > Build APK(s)** seçin. Çıktı: `app/build/outputs/apk/debug/app-debug.apk`.

## Kullanım
- Tarih + saat: bir defalık hatırlatma.
- Yalnız tarih: seçilen gün 09:00 itibarıyla günlük tekrar (varsayılan saat 09:00).
- Türkçe TTS motoru ve Türkçe ses verisi Android sisteminde kurulu olmalıdır. Android güvenlik modeli gereği uygulama bunları sessizce yükleyemez. Gerekirse Android'in **Metin okuma çıkışı** ayarlarından Türkçe ses verisini yükleyin.
- Kesin alarm izni verilmezse Android hatırlatmayı geciktirebilir.
- Widget, Android'in periyodik güncelleme sınırı nedeniyle yaklaşık 30 dakikada bir yenilenir; dakika dakika canlı sayaç değildir.

## Not
Bu paket kaynak projedir, derlenmiş APK değildir. Üretim öncesi gerçek cihazda TTS, arka plan başlatma, Android 14/15 izinleri ve widget testleri gereklidir.
